# Impact Gate Agent Plugin

This directory contains the shared Codex/OpenAI and Claude Code plugin package
for Impact Gate. The backend MCP endpoint is the production API origin. The
terms URL and reviewer walkthrough URL must be finalized before public
submission.

Impact Gate supplies read-only, tenant-authorized system-wide impact evidence
to the host agent. The host remains responsible for inspecting and editing the
current checkout. The plugin does not install a local daemon, run a repository
indexer, edit files, post PR comments, merge changes, or start reindex jobs.

## Package contents

- `plugin.json` and `mcp.json`: portable OpenAI/Codex package files.
- `.claude-plugin/plugin.json`, `.claude-plugin/marketplace.json`, and
  `.mcp.json`: Claude Code package and private-marketplace metadata.
- `skills/setup`: one-time browser authorization and repository onboarding.
- `skills/impact-analysis`: impact, consumer, API-flow, and function-usage
  workflow.
- `skills/verify-fix`: evidence-based verification after a local change.
- `evals/positive` and `evals/negative`: five positive and three negative
  acceptance cases, with safe mocked MCP responses for offline evaluation.
- `scripts/package-check.mjs`: dependency-free package and manifest check.

Both hosts connect to the same production endpoint:

```text
https://mcp.impactgate.in/
```

The server must implement OAuth
2.1/PKCE and the six read-only tools listed in `evals/tool-contract.json`.
There are no API keys, client secrets, tenant IDs, or tokens in this package.

On the Impact Gate backend, configure `AGENT_OAUTH_SIGNING_KEY` with a random
secret (for example, `openssl rand -hex 32`) before enabling this OAuth flow.
The backend also needs its public Firebase web configuration so the hosted
authorization page can sign users in. If the signing key is unset, the
existing Firebase bearer-token API remains available for internal testing, but
the public Codex/Claude OAuth connection is not ready.

## Installation and authorization

### OpenAI/Codex

1. Confirm the production endpoint and listing metadata in this directory.
2. Add the package's containing marketplace to the supported Codex/OpenAI
   plugin surface, for example:

   ```bash
   codex plugin marketplace add <owner>/<marketplace-repository>
   ```

3. Install **Impact Gate** from that marketplace in the supported Codex plugin
   directory. The Codex CLI and Codex desktop are supported plugin surfaces;
   the Codex IDE extension is not a plugin surface for this package format.
4. Start a session and run the packaged setup skill. On the first Impact Gate
   request, complete the browser sign-in, read-only consent, and workspace
   selection if more than one workspace matches.

### Claude Code

For a private Git marketplace, replace the placeholders in
`.claude-plugin/marketplace.json`, then run:

```bash
claude plugin marketplace add <owner>/<marketplace-repository>
claude plugin install impact-gate@<marketplace-name>
```

For a local smoke session without installing it:

```bash
claude plugin validate ./plugins/impact-gate-agent --strict
claude --plugin-dir ./plugins/impact-gate-agent
```

Use `/plugin`, `/mcp`, and `/reload-plugins` in the test session. Complete the
OAuth browser flow from `/mcp` when prompted; do not paste an API key into the
repository or plugin files.

## What the agent sends

The setup skill reads, in order, the current Git remote, branch and commit,
changed file names, and only the bounded unified diff needed for an explicit
local-change analysis. A normal unrelated coding question does not trigger
Impact Gate. Tool responses must identify the indexed commit, observation
window, coverage, stale/partial state, and uncertainty.

The common tools are:

1. `impactgate_workspace_status`
2. `impactgate_analyze_change`
3. `impactgate_find_consumers`
4. `impactgate_get_api_flow`
5. `impactgate_get_function_usage`
6. `impactgate_verify_fix`

The response envelope is `schemaVersion: 1`. The agent must preserve the
distinction between verified, possible, not-affected, and unknown evidence;
between API-attributed requests and measured function entries; and between
`resolved`, `remaining`, and `cannot_verify`. Zero callers never means “safe
to delete.”

## Checks

From this directory, run the dependency-free package check:

```bash
node scripts/package-check.mjs
```

It parses every JSON file, checks required paths and metadata, confirms both
host configurations use the same HTTPS endpoint, checks the six-tool contract,
and rejects hooks, credentials, and non-placeholder secrets. It performs no
network requests and does not authenticate.

If the Claude CLI is installed, also run:

```bash
claude plugin validate ./plugins/impact-gate-agent --strict
```

The acceptance cases can be run with the current Claude Code eval runner. They
use suite-local mock responses and therefore do not contact the placeholder or
production MCP endpoint:

```bash
claude plugin eval ./plugins/impact-gate-agent --mocks record --no-publish
```

Running the eval suite requires a compatible Claude Code version and host
authentication. No publication, review, or directory approval is asserted by
this package.
