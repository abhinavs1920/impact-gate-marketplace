/* global console, process */
import { readdir, readFile } from "node:fs/promises";
import { existsSync } from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const failures = [];

function assert(condition, message) {
  if (!condition) failures.push(message);
}

async function json(path) {
  try {
    return JSON.parse(await readFile(path, "utf8"));
  } catch (error) {
    failures.push(`${relative(root, path)}: invalid JSON (${error.message})`);
    return null;
  }
}

async function filesUnder(directory) {
  const entries = await readdir(directory, { withFileTypes: true });
  const files = [];
  for (const entry of entries) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) files.push(...(await filesUnder(path)));
    else files.push(path);
  }
  return files;
}

const allFiles = await filesUnder(root);
const jsonPaths = allFiles.filter((path) => path.endsWith(".json"));
const parsed = new Map();
for (const path of jsonPaths) parsed.set(relative(root, path), await json(path));

const portable = parsed.get("plugin.json");
const openAiMcp = parsed.get("mcp.json");
const claude = parsed.get(".claude-plugin/plugin.json");
const claudeMarketplace = parsed.get(".claude-plugin/marketplace.json");
const claudeMcp = parsed.get(".mcp.json");
const contract = parsed.get("evals/tool-contract.json");

const openAiServer = openAiMcp?.mcpServers?.["impact-gate"];
const claudeServer = claudeMcp?.mcpServers?.["impact-gate"];
const endpoint = openAiServer?.url;

assert(portable?.name === "impact-gate", "portable manifest must be named impact-gate");
assert(portable?.version === "0.1.0", "portable manifest must have version 0.1.0");
assert(
  portable?.extensions?.["com.openai"]?.onboardingSkill === "./skills/setup/SKILL.md",
  "OpenAI onboarding skill path is incorrect",
);
assert(openAiServer?.type === "streamable-http", "OpenAI MCP server must use streamable-http");
assert(
  typeof endpoint === "string" && endpoint.startsWith("https://"),
  "OpenAI MCP endpoint must be HTTPS",
);
assert(claude?.name === "impact-gate", "Claude manifest must be named impact-gate");
assert(claude?.version === "0.1.0", "Claude manifest must have version 0.1.0");
assert(claude?.icon === "./assets/logo.svg", "Claude icon path is incorrect");
assert(claudeServer?.type === "streamable-http", "Claude MCP server must use streamable-http");
assert(claudeServer?.url === endpoint, "Codex and Claude MCP endpoints must match");
assert(
  claudeMarketplace?.plugins?.[0]?.name === "impact-gate",
  "Claude marketplace must point to impact-gate",
);
assert(
  claudeMarketplace?.plugins?.[0]?.source === "./",
  "Claude marketplace source must be the plugin root",
);
assert(contract?.schemaVersion === 1, "tool contract must use schemaVersion 1");
assert(contract?.tools?.length === 6, "tool contract must contain six tools");

const expectedTools = [
  "impactgate_workspace_status",
  "impactgate_analyze_change",
  "impactgate_find_consumers",
  "impactgate_get_api_flow",
  "impactgate_get_function_usage",
  "impactgate_verify_fix",
];
assert(
  JSON.stringify(contract?.tools?.map((tool) => tool.name)) === JSON.stringify(expectedTools),
  "tool contract names or order changed",
);
assert(
  contract?.tools?.every((tool) => tool.readOnly === true),
  "all contract tools must be read-only",
);

const positive = portable?.extensions?.["com.openai"]?.review?.test_cases?.positive;
const negative = portable?.extensions?.["com.openai"]?.review?.test_cases?.negative;
assert(positive?.length === 5, "OpenAI review metadata must contain exactly five positive cases");
assert(negative?.length === 3, "OpenAI review metadata must contain exactly three negative cases");

for (const path of [
  "README.md",
  "skills/setup/SKILL.md",
  "skills/impact-analysis/SKILL.md",
  "skills/verify-fix/SKILL.md",
  "assets/logo.svg",
  "assets/logo-dark.svg",
])
  assert(existsSync(join(root, path)), `${path} is missing`);

const skillText = await Promise.all([
  readFile(join(root, "skills/setup/SKILL.md"), "utf8"),
  readFile(join(root, "skills/impact-analysis/SKILL.md"), "utf8"),
  readFile(join(root, "skills/verify-fix/SKILL.md"), "utf8"),
]);
const skillBundle = skillText.join("\n");
for (const tool of expectedTools)
  assert(skillBundle.includes(tool), `skills must document ${tool}`);
assert(
  !skillBundle.match(/hooks|autonomous\s+edit/i),
  "skills must not add hooks or autonomous edits",
);

for (const [label, config] of [
  ["OpenAI", openAiMcp],
  ["Claude", claudeMcp],
]) {
  const text = JSON.stringify(config);
  assert(
    !/clientSecret|apiKey|accessToken|password/i.test(text),
    `${label} MCP config contains a credential-like key`,
  );
  assert(
    !config?.mcpServers?.["impact-gate"]?.headers,
    `${label} MCP config must not contain headers or tokens`,
  );
}
assert(!portable?.extensions?.["com.openai"]?.hooks, "OpenAI manifest must not declare hooks");
assert(!claude?.hooks, "Claude manifest must not declare hooks");

const caseDirectories = async (group) => {
  const directory = join(root, "evals", group);
  const entries = await readdir(directory, { withFileTypes: true });
  return entries.filter((entry) => entry.isDirectory()).map((entry) => entry.name);
};
assert((await caseDirectories("positive")).length === 5, "evals/positive must contain five cases");
assert((await caseDirectories("negative")).length === 3, "evals/negative must contain three cases");

if (failures.length) {
  console.error("Impact Gate plugin package check failed:");
  for (const failure of failures) console.error(`- ${failure}`);
  process.exit(1);
}

console.log(
  `Impact Gate plugin package check passed (${jsonPaths.length} JSON files, six read-only tools, five positive and three negative cases).`,
);
