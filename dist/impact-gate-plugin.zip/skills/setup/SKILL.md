---
name: setup
description: Connect the current Git repository to an Impact Gate workspace with one browser authorization and no repository credentials.
---

# Set up Impact Gate

Use this workflow only when the user asks about API impact, consumers,
cross-repository dependencies, runtime usage, retirement, or Impact Gate setup.
Do not invoke it for an unrelated local coding question.

## Identify the current checkout

Read these values in order, using the host's normal shell and repository tools:

1. `git remote get-url origin`
2. current branch and full commit SHA
3. `git diff --name-status`
4. a bounded unified diff only if the requested analysis needs an unpushed
   local change

Send repository identity and commit metadata to Impact Gate. Do not send an
arbitrary repository, tenant ID, token, credential, or full source tree. Send a
bounded diff only after the user has asked for local unpushed-change analysis.

## Authorize once

Call `impactgate_workspace_status` with the detected repository full name and
remote URL. If the server returns an OAuth challenge, direct the user to the
browser authorization flow. The user signs in and approves read-only
`impact:read` access. Never ask the user to paste an API key into the checkout.

If one workspace matches, continue with it. If multiple workspaces match,
show only the safe display names and opaque workspace IDs returned by the
server, ask the user to choose once, and use the selected opaque ID for the
follow-up request. Do not infer authorization from a workspace ID supplied by
the model or user; the server must enforce membership on every read.

## Report the connection state

Summarize the matched repository, indexed SHA, index status, API-flow/runtime
availability, and one next action when setup is incomplete. Preserve stale,
partial, unknown, and missing-data states explicitly. Do not call a missing
index “no impact.”

Impact Gate is read-only. Do not edit files, post PR comments, merge changes,
change settings, or trigger reindexing as part of setup.
