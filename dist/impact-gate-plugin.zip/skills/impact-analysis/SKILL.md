---
name: impact-analysis
description: Analyze API contract changes, consumers, API flows, and function usage with bounded, tenant-authorized Impact Gate evidence.
---

# Analyze system impact

Use this workflow when the user asks what an API or contract change affects,
which services consume an endpoint or field, how a function is reached, what
runtime usage exists, or whether an API is a retirement candidate. Keep normal
local code questions with the host's native index.

## Collect bounded context

Before calling Impact Gate, inspect the current checkout:

1. `git remote get-url origin`
2. branch and full commit SHA
3. `git diff --name-status`
4. the smallest bounded unified diff needed for an explicit unpushed-change
   analysis

Prefer repository full name plus known base/head SHA or pull request number.
Do not send a full repository, secrets, credentials, arbitrary tenant IDs, or
unbounded source. Respect the server's input and result limits.

## Select the read-only tool

- Use `impactgate_workspace_status` to connect the current repository and
  inspect index freshness and available evidence.
- Use `impactgate_analyze_change` for a branch, pull request, contract file,
  bounded diff, endpoint, or field change.
- Use `impactgate_find_consumers` for endpoint, operation, field, or service
  consumers. A caller is not automatically proven to read a particular field.
- Use `impactgate_get_api_flow` for the provider handler, reachable functions,
  outbound calls, unresolved boundaries, and source links for an API operation.
- Use `impactgate_get_function_usage` for a function ID or repository/file/line
  location. Preserve the count basis exactly.

Never invoke a write action. The available MVP tools are idempotent reads and
must not edit repositories, mutate pull requests, merge code, alter settings,
or start indexing.

## Explain the result

Present the result in this order:

```text
Impact Gate evidence

Authoritative result: ...
Verified: ...
Possible or unresolved: ...
Runtime: ...
Coverage: ...
Recommended next step: ...
```

Include the indexed commit, observation window, repository/file/line links,
contract semantics, affected services, and graph freshness when returned.
Keep `unknown`, `possible`, stale, partial, and unresolved states explicit.
Never translate them into “safe,” “no impact,” or “guaranteed.” For retirement,
say “retirement candidate” or “requires review”; zero known callers is not proof
that an API can be removed.

When reporting function counts, label `api_requests` as static reachability
attribution and `measured_function_entry` as instrumented function entries.
Never claim the former proves exactly how many times a function executed.
