---
name: verify-fix
description: Verify whether a local API migration changed the original Impact Gate finding without overstating incomplete evidence.
---

# Verify a proposed fix

Use this workflow only after the user asks to verify an earlier Impact Gate
finding or API migration. The host agent reads and edits the current checkout;
Impact Gate supplies the cross-repository evidence.

## Capture the before and after context

Read the current Git remote, branch, full SHA, changed file names, and the
smallest bounded diff needed by the server. Prefer a known base SHA and head
SHA or pull request number. Include the earlier opaque `findingId` when one is
available. Do not send secrets, credentials, tenant IDs, a full repository, or
an unbounded diff. Do not persist a local diff after the request.

## Call the verification tool

Call `impactgate_verify_fix` with repository identity and the bounded change
context. The server must authorize the workspace independently of any ID in
the request. Do not use a different workspace to make a result look resolved.

## Report the decision

Return one of the server's states exactly:

- `resolved`: describe which evidence changed and cite the source references.
- `remaining`: list the findings and unresolved consumers that remain.
- `cannot_verify`: explain the missing index, stale snapshot, incomplete graph,
  or other evidence boundary. This state is not a pass.

Also report coverage changes, indexed SHA, observation window, stale/partial
status, and the authoritative PR or dashboard link when the server provides
one. Do not say “fixed,” “safe,” or “complete” when evidence is unknown,
stale, partial, or unresolved.

Verification is read-only. Do not edit the repository, post comments, merge a
PR, change workspace settings, or trigger a reindex from this workflow.
