---
type: regex
pattern: "cannot_verify|remaining|resolved|not a pass|incomplete"
flags: i
---
