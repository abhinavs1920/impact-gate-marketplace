---
name: verify-incomplete
description: Report cannot_verify when the evidence is incomplete.
runs: 1
max_turns: 8
allowed_tools: [Read, Glob, Grep, Skill]
expected_outcome: The agent reports cannot_verify as a non-pass when evidence is incomplete.
---

Verify that the API migration fixes the original Impact Gate finding. If the
repository or evidence is not complete enough, say `cannot_verify` and explain
why that is not a pass.
