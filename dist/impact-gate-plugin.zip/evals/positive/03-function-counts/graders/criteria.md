---
type: regex
pattern: "api_requests|measured_function_entry|attribut|measured"
flags: i
---
