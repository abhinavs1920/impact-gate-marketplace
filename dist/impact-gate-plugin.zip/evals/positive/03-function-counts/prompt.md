---
name: function-counts
description: Preserve the distinction between attributed and measured usage.
runs: 1
max_turns: 8
allowed_tools: [Read, Glob, Grep, Skill]
expected_outcome: The agent labels API-attributed requests separately from measured function entries.
---

How does `normalizeOrder()` fit into the system, and how often is it used?
Report API-attributed request counts separately from measured function-entry
counts, including the observation window and source references.
