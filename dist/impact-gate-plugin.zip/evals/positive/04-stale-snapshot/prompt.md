---
name: stale-snapshot
description: Surface stale indexed evidence instead of claiming current certainty.
runs: 1
max_turns: 8
allowed_tools: [Read, Glob, Grep, Skill]
expected_outcome: The agent names the indexed SHA and explains stale or partial coverage.
---

Review the impact of this route change and tell me whether the indexed result
is current. Show the indexed commit, observation window, and any stale or
partial coverage explicitly.
