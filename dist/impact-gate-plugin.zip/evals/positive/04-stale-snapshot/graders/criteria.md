---
type: regex
pattern: "stale|indexed|SHA|partial|current certainty"
flags: i
---
