---
type: regex
pattern: "Impact Gate evidence|Coverage|uncertain|stale|partial"
flags: i
---
