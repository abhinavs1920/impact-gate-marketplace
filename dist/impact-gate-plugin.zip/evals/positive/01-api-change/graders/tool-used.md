---
type: tool_used
tool: mcp__plugin_impact-gate_impact-gate__impactgate_analyze_change
---
