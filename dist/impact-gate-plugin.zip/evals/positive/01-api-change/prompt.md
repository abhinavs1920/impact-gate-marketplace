---
name: api-change
description: Analyze a contract change and preserve uncertainty.
runs: 1
max_turns: 8
allowed_tools: [Read, Glob, Grep, Skill]
expected_outcome: The agent uses Impact Gate and reports evidence, freshness, and uncertainty without editing.
---

What will this API change affect? The changed file is `openapi/orders.yaml`.
Use the current repository identity and the read-only Impact Gate workflow. Give
me affected services, evidence links, runtime context if available, and the
limitations of the result.
