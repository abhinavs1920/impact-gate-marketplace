---
name: field-consumers
description: Distinguish endpoint callers from field-proven consumers.
runs: 1
max_turns: 8
allowed_tools: [Read, Glob, Grep, Skill]
expected_outcome: The agent distinguishes endpoint callers from consumers proven to read a field.
---

Who consumes `GET /v1/orders/{id}`, and which consumers read
`response.customer.tier`? Use the Impact Gate consumer lookup and state any
unresolved or possible consumers.
