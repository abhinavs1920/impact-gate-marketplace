---
type: regex
pattern: "Impact Gate|API impact"
match: not_contains
flags: i
---
