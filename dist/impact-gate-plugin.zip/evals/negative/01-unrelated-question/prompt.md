---
name: unrelated-question
description: Do not trigger Impact Gate for unrelated local coding work.
runs: 1
max_turns: 6
allowed_tools: [Read, Glob, Grep, Skill]
expected_outcome: The agent does not invoke an Impact Gate tool.
---

Rename this local variable to make the function easier to read. This is not an
API or dependency-impact question.
