---
type: tool_used
tool: mcp__plugin_impact-gate_impact-gate__impactgate_find_consumers
---
