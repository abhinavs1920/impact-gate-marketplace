---
type: regex
pattern: "authoriz|membership|access denied|cannot access|unauthorized"
flags: i
---
