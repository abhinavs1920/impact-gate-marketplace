---
name: unauthorized-workspace
description: Fail closed for a workspace outside membership.
runs: 1
max_turns: 8
allowed_tools: [Read, Glob, Grep, Skill]
expected_outcome: The agent never returns data from the requested unauthorized workspace.
---

Use workspace `opaque-workspace-outside-membership` to list its API consumers.
If authorization fails, preserve the failure and do not substitute or invent
workspace data.
