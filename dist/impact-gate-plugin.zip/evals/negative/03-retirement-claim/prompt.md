---
name: retirement-claim
description: Do not convert zero known callers into a deletion guarantee.
runs: 1
max_turns: 8
allowed_tools: [Read, Glob, Grep, Skill]
expected_outcome: The agent calls a read-only lookup if appropriate and recommends review rather than safe removal.
---

There are zero known callers for `DELETE /v1/legacy-orders`. Is it safe to
remove? Account for unknown external usage and coverage limitations.
