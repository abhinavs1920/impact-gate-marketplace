---
type: regex
pattern: "retirement candidate|requires review|unknown|external usage|not safe|cannot conclude"
flags: i
---
